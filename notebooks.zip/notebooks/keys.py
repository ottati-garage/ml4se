MONGO_URL_TDNETDBS = "mongodb://absolutelynooblel:Flyme2themoon@ds011755.mlab.com:11755/tdnetdbs"
MONGO_URL_MINING = "mongodb://absolutelynooblel:Flyme2themoon@ds031551.mlab.com:31551/stock_mining"